<footer class="border-top">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-lg-6">
						<p class="copyright">Copyright &copy; 2022 All Rights Reserved with SDD</p>
					</div>
					<div class="col-lg-6">
						<ul class="d-flex footerlist">
							<li><a href="#">Faq</a></li>
							<li><a href="#">Terms & Condition</a></li>
							<li><a href="#">Privacy Policy</a></li>
						</ul>
					</div>
				</div>
			</div>
		</footer>



        <script src="{{url('/assets/js/jquery.min.js')}}"></script>
		<script src="{{url('/assets/js/popper.min.js')}}"></script>
		<script src="{{url('/assets/js/bootstrap.min.js')}}"></script>
    </body>
</html>
